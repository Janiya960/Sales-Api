﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sales_API.Models;
using Sales_API.Models.ORM;

namespace Sales_API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        public CustomerRepository rule;
        public CustomerController()
        {
            this.rule = new CustomerRepository();
        }

        #region Method to Get customers name list
        [Obsolete]
        [HttpGet]
        public IEnumerable<Cust> GetCustomerName()
        {
            var Cust = rule.GetCustName().ToList();
            return Cust;
        }
        #endregion

        #region Method to Get Customer By customer name
        [HttpPost]
        [Obsolete]
        public IEnumerable<Customer> GetCustmerDetails(Customer ncustomer)
        {
            var cust = rule.GetCustDetails(ncustomer.customer_Name).ToList();
            return cust;
        }
        #endregion
    }
}