﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sales_API.Models;
using Sales_API.Models.ORM;

namespace Sales_API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ItemController : ControllerBase
    {
        public ItemRepository rule;
        public ItemController()
        {
            this.rule = new ItemRepository();
        }

        #region Method to Get item code list
        [Obsolete]
        [HttpGet]
        public IEnumerable<Item1> GetItemCode()
        {
            var itm = rule.GetItemCodeDb().ToList();
            return itm;
        }
        #endregion

        #region Method to Get item By item code
        [HttpPost]
        [Obsolete]
        public IEnumerable<Item> GetItemDetails(Item nItem)
        {
            var cust = rule.GetItemDetailsDb(nItem.item_Code).ToList();
            return cust;
        }
        #endregion
    }
}