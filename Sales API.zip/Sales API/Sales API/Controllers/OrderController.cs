﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sales_API.Models;
using Sales_API.Models.ORM;

namespace Sales_API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        public OrderRepository rule;
        public OrderController()
        {
            this.rule = new OrderRepository();
        }

        #region Method for Add order details
        [Obsolete]
        [HttpPost]
        /*public string AddOrderDetails(string CustName, string invoice_No, DateTime invoice_Date, string ref_No, string Note, string Excl_Amount, string Tax_Amount,string Incl_Amount,int item_Id,int quantity)
        {*/
        public string AddOrderDetails(Order norder)
        {
            var user = rule.AddOrderDetailsDb(norder.CustName, norder.invoice_No, norder.invoice_Date, norder.ref_No, norder.Note, norder.Excl_Amount, norder.Tax_Amount, norder.Incl_Amount, norder.item_Id, norder.quantity);
            return user;
        }
        #endregion

        #region Method to Get order details
        [Obsolete]
        [HttpGet]
        public IEnumerable<OrderDetails> GetOrderDetails()
        {
            var ordDel = rule.GetOrderDetailsDb().ToList();
            return ordDel;
        }
        #endregion

        #region Method to Get order details By order id
        [HttpPost]
        [Obsolete]
        public IEnumerable<OrderDetails> GetOrderDetailsByOrderId(OrderDetails norder)
        {
            var cust = rule.GetOrderDetailsByOrderIdDb(norder.order_Id).ToList();
            return cust;
        }
        #endregion

        #region Method to Delete order details By order id
        [HttpPost]
        [Obsolete]
        public string DelOrderDetailsByOrderId(OrderDetails norder)
        {
            var order = rule.DelOrderDetailsByOrderIdDb(norder.order_Id);
            return order;
        }
        #endregion
    }
}
