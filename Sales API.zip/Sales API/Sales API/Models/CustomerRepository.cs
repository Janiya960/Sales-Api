﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Sales_API.Models.ORM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sales_API.Models
{
    public class CustomerRepository
    {
        private readonly EFDbModel context;

        public CustomerRepository()
        {
            context = new EFDbModel();
        }

        #region Get customers name list
        [Obsolete]

        public IEnumerable<Cust> GetCustName()
        {
            var customer = context.Set<Cust>().FromSqlRaw("GetCustomerName").ToList().AsEnumerable<Cust>();
            return customer;
        }
        #endregion

        #region Get customers By customers name
        [Obsolete]

        public IEnumerable<Customer> GetCustDetails(string customer_Name)
        {
            var user = context.Set<Customer>().FromSqlRaw("GetCutomerDetails @customer_Name ", new SqlParameter("customer_Name", customer_Name)).ToList().AsEnumerable<Customer>();
            return user;
        }
        #endregion


    }
}
