﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Sales_API.Models.ORM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sales_API.Models
{
    public class ItemRepository
    {
        private readonly EFDbModel context;

        public ItemRepository()
        {
            context = new EFDbModel();
        }

        #region Get Item code list
        [Obsolete]

        public IEnumerable<Item1> GetItemCodeDb()
        {
            var itm = context.Set<Item1>().FromSqlRaw("GetItemCode").ToList().AsEnumerable<Item1>();
            return itm;
        }
        #endregion

        #region Get Item By Item code
        [Obsolete]

        public IEnumerable<Item> GetItemDetailsDb(string item_Code)
        {
            var user = context.Set<Item>().FromSqlRaw("GetItemDetails @item_Code ", new SqlParameter("item_Code", item_Code)).ToList().AsEnumerable<Item>();
            return user;
        }
        #endregion
    }
}
