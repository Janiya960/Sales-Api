﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sales_API.Models.ORM
{
    public class EFDbModel: DbContext
    {
        public EFDbModel() { }
        public EFDbModel(DbContextOptions<EFDbModel> options)
           : base(options)
        {
        }

        public static string ConnectionString { get; set; }

        public DbSet<Customer> Customer { get; set; }
        public DbSet<Cust> Cust { get; set; }

        public DbSet<Item> Item { get; set; }
        public DbSet<Item1> Item1 { get; set; }

        public DbSet<Order> Order { get; set; }
        public DbSet<OrderDetails> OrderDetails { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(ConnectionString);
        }
    }
}
