﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Sales_API.Models.ORM
{
    public class Customer
    {
        [Key]
        public int customer_Id { get; set; }
        public string customer_Name { get; set; }
        public string customer_Add1 { get; set; }
        public string customer_Add2 { get; set; }
        public string customer_Add3 { get; set; }
        public string customer_Suburb { get; set; }
        public string customer_State { get; set; }
        public string customer_PostCode { get; set; }
    }
}
