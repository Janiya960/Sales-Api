﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Sales_API.Models.ORM
{
    public class Cust
    {
        [Key]
        public string customer_Name { get; set; }
        
    }
}
