﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Sales_API.Models.ORM
{
    public class Item
    {
        [Key]
        public int item_Id { get; set; }
        public string item_Code { get; set; }
        public string item_Name { get; set; }
        public string item_Desc { get; set; }
        public string item_Price { get; set; }
        
    }
}
