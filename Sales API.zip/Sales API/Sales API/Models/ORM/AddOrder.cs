﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sales_API.Models.ORM
{
    public class AddOrder
    {
        
        public string CustName { get; set; }
        public string invoice_No { get; set; }
        public DateTime invoice_Date { get; set; }
        public string ref_No { get; set; }
        public string Note { get; set; }
        public string Excl_Amount { get; set; }
        public string Tax_Amount { get; set; }
        public string Incl_Amount { get; set; }
        public int item_Id { get; set; }
        public int quantity { get; set; }
    }
}