﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Sales_API.Models.ORM;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Sales_API.Models
{
    public class OrderRepository
    {
        private readonly EFDbModel context;

        public OrderRepository()
        {
            context = new EFDbModel();
        }


        #region Add order details
        [Obsolete]

        public string AddOrderDetailsDb(string CustName, string invoice_No, string invoice_Date, string ref_No, string Note, string Excl_Amount, string Tax_Amount, string Incl_Amount, string item_Id, string quantity)
        {
            string msg = "";

            var retMsg = new SqlParameter("RetMsg", "")
            {
                Direction = ParameterDirection.Output,
                DbType = DbType.String,
                Size = 100,
            };

                    var eventDet = context.Set<Order>().FromSqlRaw("addOrderDetails @CustName, @invoice_No, @invoice_Date, @ref_No, @Note,@Excl_Amount,@Tax_Amount,@Incl_Amount,@item_Id,@quantity, @RetMsg OUTPUT", new[] { new SqlParameter("CustName", CustName), new SqlParameter("invoice_No", invoice_No), new SqlParameter("invoice_Date", invoice_Date), new SqlParameter("ref_No", ref_No), new SqlParameter("Note", Note),new SqlParameter("Excl_Amount", Excl_Amount), new SqlParameter("Tax_Amount", Tax_Amount),new SqlParameter("Incl_Amount", Incl_Amount), new SqlParameter("item_Id", item_Id), new SqlParameter("quantity", quantity),retMsg }).ToList().AsEnumerable<Order>().FirstOrDefault();
                    var val = retMsg.Value.ToString();
                    
                    msg = val;

            return msg;
        }

        #endregion

        #region Get order details
        [Obsolete]

        public IEnumerable<OrderDetails> GetOrderDetailsDb()
        {
            var customer = context.Set<OrderDetails>().FromSqlRaw("GetAllOrderDetails").ToList().AsEnumerable<OrderDetails>();
            return customer;
        }
        #endregion

        #region Get order details By order id
        [Obsolete]

        public IEnumerable<OrderDetails> GetOrderDetailsByOrderIdDb(int order_Id)
        {
            var user = context.Set<OrderDetails>().FromSqlRaw("GetAllOrderDetailsById @order_Id ", new SqlParameter("order_Id", order_Id)).ToList().AsEnumerable<OrderDetails>();
            return user;
        }
        #endregion

        #region Delete order details By order id
        [Obsolete]

        public string DelOrderDetailsByOrderIdDb(int order_Id)
        {
            var retMsg = new SqlParameter("RetMsg", "")
            {
                Direction = ParameterDirection.Output,
                DbType = DbType.String,
                Size = 100,
            };

            var userDel = context.Set<OrderDetails>().FromSqlRaw("DeleteOrderDetailsById  @order_Id, @RetMsg OUTPUT ", new SqlParameter("order_Id", order_Id), retMsg).ToList().AsEnumerable<OrderDetails>().FirstOrDefault();
            var val = retMsg.Value.ToString();
            return val;
        }
        #endregion


    }
}
